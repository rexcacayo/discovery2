@extends('redprintUnity::page')

@section('title') Dashboard @stop

@section('content')
        
    <div class="card" id="app">

        <div class="card-body">
            Dashboard
        </div>
    </div>
@stop