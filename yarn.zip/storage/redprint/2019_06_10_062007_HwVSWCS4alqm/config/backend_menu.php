<?php

return  [
  0 => 
   [
    'text' => 'Clientes',
    'route' => 'cliente.index',
    'icon' => 'icon-folder',
  ],
]
;