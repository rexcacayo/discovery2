<?php $__env->startSection('title'); ?> Dashboard <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
        
    <div class="card" id="app">

        <div class="card-body">
            Dashboard
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make(config('redprint.main-app-layout', 'redprintUnity::page'), \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>