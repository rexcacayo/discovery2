<?php $__env->startSection('title'); ?> Dashboard <?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title'); ?> Redprint Relationship Builder <?php $__env->stopSection(); ?>
<?php $__env->startSection('page_subtitle'); ?> Connect Models <?php $__env->stopSection(); ?>
<?php $__env->startSection('page_icon'); ?> <i class="icon-layers"></i> <?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
  <link rel="stylesheet" type="text/css" href="/vendor/redprint/css/redprint.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card" id="app">
        <div class="card-body">
          <a href="#" data-toggle="modal" data-target="#newRelation" class="btn btn-success pull-right"><i class="fa fa-code-fork"></i>New Relation</a>

          <div class="row">
            <?php $__currentLoopData = $relations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6">
              <div class="tree">
                <ul>
                  <li>
                    <a href="#"><?php echo e($relation['model']); ?></a>
                    <ul>
                      <?php $__currentLoopData = $relation['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li>
                        <a href="#"><?php echo e($data['type']); ?></a>
                        <ul>
                          <li>
                            <a href="#"><?php echo e($data['model']); ?></a>
                            <ul>
                              <li><a href="#"><?php echo e($data['foreign_key']); ?></a></li>
                              <li><a href="#"><?php echo e($data['local_key']); ?></a></li>
                            </ul>
                          </li>
                        </ul>
                      </li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                  </li>
                </ul>
              </div>
            </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        
    </div>
</div>

<?php $__env->startSection('modals'); ?>
##parent-placeholder-0c1c163a4d648da177a48fddc7a3a5a788b17ac6##
<div class="modal fade" tabindex="-1" role="dialog" id="newRelation">
  <form method="post" action="<?php echo e(route('redprint.relationship.new')); ?>">
  <?php echo csrf_field(); ?>

  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">New Relation</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label for="model">Base Model</label>
          <select name="model" class="form-control">
            <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($model); ?>"><?php echo e($model); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        <div class="form-group">
          <label for="relationship">Relationship</label>
          <select name="relationship" class="form-control">
            <?php $__currentLoopData = $relationshipTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($type); ?>"><?php echo e($type); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        <div class="form-group">
          <label for="with">With</label>
          <select name="with" class="form-control">
            <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($model); ?>"><?php echo e($model); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Build Relationship</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make(config('redprint.redprint-layout', 'redprintUnity::page'), \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>