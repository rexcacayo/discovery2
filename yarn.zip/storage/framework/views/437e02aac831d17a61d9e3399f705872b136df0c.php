<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/css/estilos.css')); ?>" >


<?php $__env->startSection('title'); ?> Cuestionario - Form <?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title'); ?> Cuestionario <?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
  ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##
  Cuestionario
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
  <link rel="stylesheet" href="<?php echo e(asset('vendor/redprintUnity/vendor/summernote/summernote-bs4.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  ##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
  <script src="<?php echo e(asset('vendor/redprintUnity/vendor/summernote/summernote-bs4.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <form method="post" action="<?php echo e(route('cuestionario.paso')); ?>" enctype="multipart/form-data" >
  <?php echo csrf_field(); ?>

  <div class="card">

    <div class="card-body row">
				        <input type="hidden" name="cliente_id" value="<?php echo e($cliente['id']); ?>" >
                
                
                 
    

<?php $__currentLoopData = $preguntasData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $preguntasItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="form-group col-md-12 col-xs-12 col-lg-12  has-feedback <?php echo e($errors->has('answer') ? 'has-error' : ''); ?>">
	<label class="control-label"> <?php echo e($preguntasItem->pregunta); ?> <span class="required">*</span></label>
  <br>
  <?php
  $input= $preguntasItem->tipo;
  
  if($input === "number"){
    $respuesta = '<input type="number" name="respuesta"  >';
  }
  if($input === "text"){
    $respuesta = '<input type="text" name="respuesta" >';
  }
  if($input === "select"){
    $respuesta = '<select name="respuesta" >';
    foreach($valores as $valor){
      $opciones[] =   '<option value="'.$valor->valor.'">'.$valor->valor.'</option>';
    }
    $respuestacerrar = '</select>';
  }

  if($input === "radio"){
    $respuesta = '';
    foreach($valores as $valor){
      $opciones[] = '<input type="radio" name="respuesta" value="'.$valor->valor.'" > '.$valor->valor.'';
    }
    $respuestacerrar = '';
  }

  if($input === "checkbox"){
    foreach($valores as $valor){
      $opciones[] = '<input type="checkbox" name="respuesta[]" value="'.$valor->valor.'" > '.$valor->valor.'';
    }

    $respuesta = '';
    $respuestacerrar = "";
    } 

    if($input === "range"){
    foreach($valores as $valor){
      if(isset($min)){
        $max = $valor->valor;
      }else{
        $min = $valor->valor;
      }
    }
    $respuesta = $min.'<input type="range" name="respuesta" list="marks" min="'.$min.'" max="'.$max.'" step="1" >'.$max;
    }


  ?>
 
  <input type="hidden" name="pregunta_id" value="<?php echo e($preguntasItem->id); ?>" >
	<?php echo $respuesta; ?>


  <?php
  if(isset($opciones)){
    foreach($opciones as $opcion){
     echo $opcion; 
    }
    echo $respuestacerrar;
  }
  ?>  
 
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
    </div>
    
    
      
    <div class="card-footer">
      <div class="row">
        <div class="col-sm-8">
          <button type="submit" class="btn-primary btn" >Siguiente</button>
        
        </div>
      </div>
    </div>

  </div>
  </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make(config('main-app-layout', 'redprintUnity::page'), \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>