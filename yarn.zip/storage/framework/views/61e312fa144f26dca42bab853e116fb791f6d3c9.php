<?php $__env->startSection('title'); ?>
	<?php echo e(trans('permissible::core.users')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('page_title'); ?> <?php echo e(trans('permissible::core.users')); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('page_subtitle'); ?> <?php echo e(trans('permissible::core.manage_users')); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('page_icon'); ?> <i class="icon-users"></i> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
	<div class="card-header">
		<?php if(auth()->user()->hasPermission('admins.manage')): ?>
			<a href="<?php echo e(route('permissible.user.new')); ?>" class="btn btn-success btn-sm font-white" style="border-radius: 0px !important;">
				<i class='icon-plus'></i> 
				<?php echo e(trans('permissible::core.add_new_user')); ?>

			</a>
		<?php endif; ?>


  		<?php if(count(Request::input())): ?>
        <a class="btn btn-default btn-sm float-right" href="<?php echo e(route('permissible.user.index')); ?>">
        	<i class="icon-eraser"></i> 
        	<?php echo e(trans('permissible::core.clear')); ?>

        </a>

        <a class="btn btn-info btn-sm float-right" id="searchButton">
        	<i class="icon-search"></i> 
        	<?php echo e(trans('permissible::core.modify_search')); ?>

        </a>
      <?php else: ?>
        <a class="btn btn-default btn-sm float-right" id="searchButton" data-toggle="modal" data-target="#searchModal">
  				<i class="icon-search"></i>
  				<?php echo e(trans('permissible::core.search')); ?>

  			</a>
      <?php endif; ?>

	</div>

	<div class="card-body">

		<table class="table table-bordered">
			<thead class="table-header-color">
				<td><?php echo e(trans('permissible::core.name')); ?></td>
				<td><?php echo e(trans('permissible::core.email')); ?></td>
				<td><?php echo e(trans('permissible::core.role')); ?></td>
				<td><?php echo e(trans('permissible::core.actions')); ?></td>
			</thead>

			<tbody>
				<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($user->first_name.' '.$user->last_name); ?></td>
						<td><?php echo e($user->email); ?></td>
						<td>
							<?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<span class="label label-default"><?php echo e($role->name); ?></span>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</td>
						<td>
              <?php if(function_exists('redprint') && redprint() && $user->hasRole('su')): ?>
                <?php echo e(trans('permissible::core.not_editable_redprint_mode')); ?>

              <?php else: ?>

  							<?php if(auth()->user()->hasPermission('admin.access')): ?>
                  <?php if($user->deleted_at === null): ?>
                    <a href="<?php echo e(route('permissible.user.form', $user)); ?>" class="btn btn-primary btn-xs">
                      <?php echo e(trans('permissible::core.edit')); ?>

                    </a>
                    <a href="#" data-toggle="modal" data-target="#deleteModal<?php echo e($user->id); ?>" class="btn btn-danger btn-xs">
                      <?php echo e(trans('permissible::core.delete')); ?>

                    </a>
                    <?php $__env->startSection('js'); ?>
                    ##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
                        <!-- modal starts -->
                        <div class="modal fade" id="deleteModal<?php echo e($user->id); ?>">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form method="post" class="'form-horizontal'" action="<?php echo e(route('permissible.user.delete', $user->id)); ?>" >
                                    <?php echo csrf_field(); ?>

                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <h4 class="modal-title"> <?php echo e(trans('permissible::core.delete')); ?>: <?php echo e($user->first_name.' '.$user->last_name); ?> ? </h4>
                                    </div>
                    
                                    <div class="modal-body">
                                        <?php echo e(trans('permissible::core.delete_confirmation')); ?> <b><?php echo e($user->first_name.' '.$user->last_name); ?> ?</b>
                                    </div>
                    
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(trans('permissible::core.close')); ?></button>
                                        <button class="btn btn-md btn-danger" type="submit" style="border-radius: 0px !important;"><?php echo e(trans('permissible::core.delete')); ?></button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- modal ends -->
                    <?php $__env->stopSection(); ?>
                  <?php else: ?>
                    <a href="#" class="btn btn-info btn-xs" data-toggle="modal" data-target="#restoreModal<?php echo e($user->id); ?>">
                      <?php echo e(trans('permissible::core.restore')); ?>

                    </a>
                    <a href="#" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#forceDeleteModal<?php echo e($user->id); ?>">
                      <?php echo e(trans('permissible::core.force_delete')); ?>

                    </a>
                    <?php $__env->startSection('js'); ?>
                    ##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
                        <!-- modal starts -->
                        <div class="modal fade" id="restoreModal<?php echo e($user->id); ?>">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form method="post" class="'form-horizontal'" action="<?php echo e(route('permissible.user.restore', $user->id)); ?>" >
                                    <?php echo csrf_field(); ?>

                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <h4 class="modal-title"> <?php echo e(trans('permissible::core.restore')); ?>: <?php echo e($user->first_name.' '.$user->last_name); ?> ? </h4>
                                    </div>
                    
                                    <div class="modal-body">
                                        <?php echo e(trans('permissible::core.restore_confirmation')); ?> <b><?php echo e($user->first_name.' '.$user->last_name); ?> ?</b>
                                    </div>
                    
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        <button class="btn btn-md btn-info" type="submit" style="border-radius: 0px !important;"><?php echo e(trans('permissible::core.restore')); ?></button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- modal ends -->
                        <!-- modal starts -->
                        <div class="modal fade" id="forceDeleteModal<?php echo e($user->id); ?>">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form method="post" class="'form-horizontal'" action="<?php echo e(route('permissible.user.force-delete', $user->id)); ?>" >
                                    <?php echo csrf_field(); ?>

                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                        <h4 class="modal-title"> <?php echo e(trans('permissible::core.force_delete')); ?>: <?php echo e($user->first_name.' '.$user->last_name); ?> ? </h4>
                                    </div>
                    
                                    <div class="modal-body">
                                        <?php echo trans('permissible::core.permanently_delete_confirmation', ['data' => $user->first_name.' '.$user->last_name ]); ?> ?</code>
                                    </div>
                    
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        <button class="btn btn-md btn-info" type="submit" style="border-radius: 0px !important;"><?php echo e(trans('permissible::core.force_delete')); ?></button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- modal ends -->


                    <?php $__env->stopSection(); ?>


                  <?php endif; ?>
                
  							<?php else: ?>
  								<a href="#" class="btn btn-primary btn-xs" disabled>
  									<?php echo e(trans('permissible::core.edit')); ?>

  								</a>
  							<?php endif; ?>			
              <?php endif; ?>

						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>

		<!--Pagination-->
		<div class="pull-right">
			<?php echo e($users->links()); ?>

		</div>
		<!--Ends-->
	</div>
</div>


	<!-- User search modal -->
    <div class="modal fade" id="searchModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="get" class="'form-horizontal'" action="<?php echo e(route('permissible.user.index')); ?>" >
                <?php echo csrf_field(); ?>

                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"><?php echo e(trans('permissible::core.search_users')); ?></h4>
                </div>

                <div class="modal-body">                  
                    <div class="form-group">
                        <label class="col-sm-3"><?php echo e(trans('permissible::core.name')); ?></label>
                        <div class="col-sm-9">
                            <input type="text" name="name" class="form-control" value="<?php echo e(Request::get('name')); ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-sm-3"><?php echo e(trans('permissible::core.email')); ?></label>
                        <div class="col-sm-9">
                            <input type="text" name="email" class="form-control" value="<?php echo e(Request::get('email')); ?>">
                        </div>
                    </div>                                             
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(trans('permissible::core.close')); ?></button>
                    <button type="submit" class="btn btn-primary" ><?php echo e(trans('permissible::core.search')); ?></button>
                </div>
                </form>
            </div>
        </div>
    </div>
	<!-- search modal ends -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('redprintUnity::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>