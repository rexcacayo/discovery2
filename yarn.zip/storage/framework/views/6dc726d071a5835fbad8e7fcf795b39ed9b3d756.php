<?php $__env->startSection('title'); ?> Pregunta - Form <?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title'); ?> Pregunta <?php $__env->stopSection(); ?>
<?php $__env->startSection('page_subtitle'); ?> <?php if($pregunta->exists): ?> <?php echo e(trans('redprint::core.editing')); ?> Pregunta: <?php echo e($pregunta->id); ?> <?php else: ?> Add New Pregunta <?php endif; ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
  ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##
  Pregunta
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
  <link rel="stylesheet" href="<?php echo e(asset('vendor/redprintUnity/vendor/summernote/summernote-bs4.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  ##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
  <script src="<?php echo e(asset('vendor/redprintUnity/vendor/summernote/summernote-bs4.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <form method="post" action="<?php echo e(route('pregunta.save')); ?>" enctype="multipart/form-data" >
  <?php echo csrf_field(); ?>

  <div class="card">

    <div class="card-body row">
		        <input type="hidden" name="id" value="<?php echo e($pregunta->id); ?>" >


               <div class="form-group has-feedback col-xs-12 col-md-12 col-lg-12 <?php echo e($errors->has('pregunta') ? 'has-error' : ''); ?>">
            <label>Pregunta</label>
            <input type="text" name="pregunta" class="form-control" value="<?php echo e($pregunta->pregunta ?: old('pregunta')); ?>">
            <?php if($errors->has('pregunta')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('pregunta')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group has-feedback col-xs-12 col-md-12 col-lg-12 <?php echo e($errors->has('formulario') ? 'has-error' : ''); ?>">
            <label>Formulario a que pertenece la pregunta</label>
            <select name='formulario' class ='form-control selectpicker' value="<?php echo e($pregunta->formulario ?: old('formulario')); ?>" placeholder='Please select a formulario' data-live-search='true' id ='cliente_id' >
                <option value="formulario1">Formulario 1</option>
                <option value="formulario2">Formulario 2</option>
            </select>
            <?php if($errors->has('formulario')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('formulario')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
        <div class="form-group has-feedback col-xs-12 col-md-12 col-lg-12 <?php echo e($errors->has('tipo') ? 'has-error' : ''); ?>">
            <label>Tipo</label>
            <select name="tipo" class ='form-control selectpicker' value="<?php echo e($pregunta->tipo ?: old('tipo')); ?>" placeholder='Please select a formulario' data-live-search='true' id ='cliente_id' >
                <option value="text">Texto</option>
                <option value="number">Númerico</option>
                <option value="range">Rango</option>
                <option value="select">Lista desplegable</option>
                <option value="checkbox">Check</option>
                <option value="radio">Opción</option>
            </select>
            <?php if($errors->has('tipo')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('tipo')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

    </div>

    <div class="card-footer">
      <div class="row">
        <div class="col-sm-8">
          <button type="submit" class="btn-primary btn" ><?php echo e(trans('redprint::core.save')); ?></button>
        </div>
      </div>
    </div>

  </div>
  </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make(config('main-app-layout', 'redprintUnity::page'), \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>