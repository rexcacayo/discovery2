<?php $__env->startSection('title'); ?> Valor - Form <?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title'); ?> Valor <?php $__env->stopSection(); ?>
<?php $__env->startSection('page_subtitle'); ?> <?php if($valor->exists): ?> <?php echo e(trans('redprint::core.editing')); ?> Valor: <?php echo e($valor->id); ?> <?php else: ?> Add New Valor <?php endif; ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
  ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##
  Valor
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
  <link rel="stylesheet" href="<?php echo e(asset('vendor/redprintUnity/vendor/summernote/summernote-bs4.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  ##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
  <script src="<?php echo e(asset('vendor/redprintUnity/vendor/summernote/summernote-bs4.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <form method="post" action="<?php echo e(route('valor.save')); ?>" enctype="multipart/form-data" >
  <?php echo csrf_field(); ?>

  <div class="card">

    <div class="card-body row">
		        <input type="hidden" name="id" value="<?php echo e($valor->id); ?>" >

<div class="form-group col-md-6 col-xs-6 col-lg-6  has-feedback <?php echo e($errors->has('pregunta_id') ? 'has-error' : ''); ?>">
	<label class="control-label"> Pregunta <span class="required">*</span></label>
	
    <select name='pregunta_id' class ='form-control selectpicker' placeholder='Please select a pregunta' data-live-search='true' id ='pregunta_id' >
        <?php $__currentLoopData = $preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entityId => $entityValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($entityId); ?>" <?php echo e($valor->pregunta_id === $entityId ? 'selected' : ''); ?> ><?php echo e($entityValue); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

  <?php if($errors->has('pregunta_id')): ?>
    <span class="help-block">
      <strong><?php echo e($errors->first('pregunta_id')); ?></strong>
    </span>
  <?php endif; ?>
</div>                <div class="form-group has-feedback col-xs-12 col-md-12 col-lg-12 <?php echo e($errors->has('valor') ? 'has-error' : ''); ?>">
            <label>Valor</label>
            <input type="text" name="valor" class="form-control" value="<?php echo e($valor->valor ?: old('valor')); ?>">
            <?php if($errors->has('valor')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('valor')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

    </div>

    <div class="card-footer">
      <div class="row">
        <div class="col-sm-8">
          <button type="submit" class="btn-primary btn" ><?php echo e(trans('redprint::core.save')); ?></button>
        </div>
      </div>
    </div>

  </div>
  </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make(config('main-app-layout', 'redprintUnity::page'), \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>