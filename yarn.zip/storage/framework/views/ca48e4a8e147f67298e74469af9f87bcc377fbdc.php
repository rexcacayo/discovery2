<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/css/estilos.css')); ?>" >


<?php $__env->startSection('title'); ?> Cuestionario - Form <?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title'); ?> Cuestionario <?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
  ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8##
  Cuestionario
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  ##parent-placeholder-2f84417a9e73cead4d5c99e05daff2a534b30132##
  <link rel="stylesheet" href="<?php echo e(asset('vendor/redprintUnity/vendor/summernote/summernote-bs4.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  ##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
  <script src="<?php echo e(asset('vendor/redprintUnity/vendor/summernote/summernote-bs4.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <form method="post" action="<?php echo e(route('cuestionario.paso')); ?>" enctype="multipart/form-data" >
  <?php echo csrf_field(); ?>

  <div class="card">

    <div class="card-body row">
				        <input type="hidden" name="cliente_id" value="<?php echo e($cliente['id']); ?>" >
                <input type="hidden" name="id" value="<?php echo e($preguntasData->id); ?>" > 
    
    


<div class="form-group col-md-12 col-xs-12 col-lg-12  has-feedback <?php echo e($errors->has('pregunta_id') ? 'has-error' : ''); ?>">
	<label class="control-label"> <?php echo e($preguntasData->pregunta); ?> <span class="required">*</span></label><br>
	<?php
  $input= $preguntasData->tipo;
  
  if($input === "number"){
    $respuesta = '<input type="number" name="respuesta" class="form-control">';
  }
  if($input === "text"){
    $respuesta = '<input type="text" name="respuesta" class="form-control">';
  }
  if($input === "select"){
    $respuesta = '<select name="respuesta" class="form-control">';
    foreach($valores as $valor){
      $opciones[] =   '<option value="'.$valor->valor.'">'.$valor->valor.'</option>';
    }
    $respuestacerrar = '</select>';
  }

  if($input === "range"){
    foreach($valores as $valor){
      if(isset($min)){
        $max = $valor->valor;
      }else{
        $min = $valor->valor;
      }
    }
    $respuesta = $min.'<input type="range" name="respuesta" list="marks" min="'.$min.'" max="'.$max.'" step="1">'.$max;
    }
    
    if($input === "radio"){
    foreach($valores as $valor){
      $opciones[] = '<input type="radio" name="respuesta" value="'.$valor->valor.'" class="form-control"> '.$valor->valor.'';
    }
    $respuesta = '';
    $respuestacerrar = "";
    }
   

    if($input === "checkbox"){
    foreach($valores as $valor){
      $opciones[] = '<input type="checkbox" name="respuesta[]" value="'.$valor->valor.'" class="form-check-input" id="inlineCheckbox1"><label class="form-check-label" for="inlineCheckbox1">'.$valor->valor.'</label> ';
    }

    $respuesta = '';
    $respuestacerrar = "";
    }


  ?>
  <?php echo $respuesta; ?>

  <?php if(isset($respuestacerrar)): ?>
    <?php $__currentLoopData = $opciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php echo $opcion; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php echo $respuestacerrar; ?>

  <?php endif; ?>  

  
</div>
      
    </div>

            
      
    <div class="card-footer">
      <div class="row">
        <div class="col-sm-8">
          <button type="submit" class="btn-primary btn" ><?php echo e(trans('redprint::core.save')); ?></button>
        </div>
      </div>
    </div>

  </div>
  </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make(config('main-app-layout', 'redprintUnity::page'), \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>