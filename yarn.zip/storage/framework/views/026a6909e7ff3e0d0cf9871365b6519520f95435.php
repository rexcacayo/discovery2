<?php $__env->startSection('body'); ?>

    <body class="login-bg">
            
        <div class="container">
            <div class="login-screen row align-items-center">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <form action="<?php echo e(route(
                            config(
                                'redprintUnity.login_post_route',
                                'backend.login.post'
                            )
                        )); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="login-container">
                            <div class="row no-gutters">
                                <div class="col-xl-4 col-lg-5 col-md-6 col-sm-12">
                                    <div class="login-box">
                                        <a href="#" class="login-logo">
                                            <img src="<?php echo e(asset(
                                                    config('redprintUnity.logo')
                                                )); ?>" alt="Backend" />
                                        </a>
                                        <div class="input-group">
                                            <span class="input-group-addon" id="email"><i class="icon-account_circle"></i></span>
                                            <input type="text" class="form-control" placeholder="Email" aria-label="email" aria-describedby="email" name="email">
                                        </div>
                                        <br>
                                        <div class="input-group">
                                            <span class="input-group-addon" id="password"><i class="icon-verified_user"></i></span>
                                            <input type="password" class="form-control" placeholder="Password" aria-label="Password" aria-describedby="password" name="password">
                                        </div>
                                        <div class="actions clearfix">
                                        <?php $__env->startSection('lost_password'); ?>
                                        <?php echo $__env->yieldSection(); ?>
                                        <button type="submit" class="btn btn-primary"><?php echo e(trans('redprintUnity::core.login')); ?></button>
                                      </div>
                                      <div class="mt-4">
                                        <?php $__env->startSection('signup'); ?>
                                        <?php echo $__env->yieldSection(); ?>
                                      </div>
                                    </div>
                                </div>
                                <div class="col-xl-8 col-lg-7 col-md-6 col-sm-12">
                                    <div class="login-slider" style="background: url(<?php echo e(asset(config('redprintUnity.login_bg'))); ?>)"></div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <footer class="main-footer no-bdr fixed-btm">
            <div class="container">
                <?php $__env->startSection('footer'); ?>
                    <?php echo config(
                            'redprintUnity.powered_by', '&copy; Redprint by Intelle Hub Inc.'
                        ); ?>

                <?php echo $__env->yieldSection(); ?>
            </div>
        </footer>
    </body>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('redprintUnity::master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>