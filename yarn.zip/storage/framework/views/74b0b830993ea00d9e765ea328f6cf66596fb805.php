<?php if(is_string($item)): ?>
    <li class="header"><?php echo e($item); ?></li>
<?php else: ?>
    <li class="<?php echo e($item['class']); ?>">
        <a href="<?php echo e($item['href']); ?>"
           <?php if(isset($item['target'])): ?> target="<?php echo e($item['target']); ?>" <?php endif; ?>
           <?php if(isset($item['submenu'])): ?> class="has-arrow" <?php endif; ?>
        >
            <span class="has-icon">
                <i class="<?php echo e(isset($item['icon']) ? $item['icon'] : 'icon-tabs-outline'); ?> <?php echo e(isset($item['icon_color']) ? 'text-' . $item['icon_color'] : ''); ?>"></i>
            </span>
            <span class="nav-title"><?php echo e($item['text']); ?></span>
        </a>
        <?php if(isset($item['submenu'])): ?>
            <ul class="<?php echo e($item['submenu_class']); ?>">
                <?php echo $__env->renderEach('redprintUnity::partials.menu-item', $item['submenu'], 'item'); ?>
            </ul>
        <?php endif; ?>
    </li>
<?php endif; ?>
