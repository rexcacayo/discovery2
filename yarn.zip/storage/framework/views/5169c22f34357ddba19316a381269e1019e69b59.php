<?php $__env->startSection('title'); ?>
    <?php if($user->id): ?>
        <?php echo e(trans('permissible::core.editing', ['data' => $user->first_name . ' ' . $user->last_name ])); ?>

    <?php else: ?>
        <?php echo e(trans('permissible::core.add_new_user')); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title'); ?>     
    <?php if($user->id): ?>
        <?php echo e(trans('permissible::core.editing', ['data' => $user->first_name . ' ' . $user->last_name ])); ?>

    <?php else: ?>
        <?php echo e(trans('permissible::core.add_new_user')); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_subtitle'); ?> 
    <?php if($user->id): ?>
        <?php echo e($user->name); ?>

    <?php else: ?>
        <?php echo e(trans('permissible::core.new')); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_icon'); ?> <i class="icon-users"></i> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">

    <div class="card-body">
        <?php if(function_exists('redprint') && redprint() && $user->hasRole('su')): ?>
            <p><?php echo e(trans('permissible::core.not_editable_redprint_mode')); ?></p>
        <?php else: ?>
        <form method="post" enctype="multipart/form-data" action="<?php echo e(route('permissible.user.save')); ?>" >
        <?php echo csrf_field(); ?>

        <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
        
            <div class="row">

                <div class="form-group col-md-6">
                    
                    <label class="control-label"><?php echo e(trans('permissible::core.first_name')); ?><span class="required">*</span></label>

                    <input type="text" class="form-control" placeholder="John" name="first_name" value="<?php echo e($user->first_name); ?>" />

                    <?php if($errors->has('first_name')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('first_name')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="form-group col-md-6">
                    <label class="control-label"><?php echo e(trans('permissible::core.last_name')); ?><span class="required">*</span></label>
                    
                    <input type="text" class="form-control" placeholder="Doe" name="last_name" value="<?php echo e($user->last_name); ?>" />

                    <?php if($errors->has('last_name')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('last_name')); ?></strong>
                        </span>
                    <?php endif; ?>

                </div>


            </div>

            <div class="row">
                <div class="form-group col-md-6">
                    <label class="control-label"><?php echo e(trans('permissible::core.email')); ?><span class="required">*</span></label>
                    <input type="email" class="form-control" placeholder="test@example.com" name="email" value="<?php echo e($user->email); ?>"/>

                    <?php if($errors->has('email')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="form-group col-md-6">
                    <label class="control-label"><?php echo e(trans('permissible::core.role')); ?></label>

                        <select name="role" class="form-control selectpicker" data-live-search="true" title="<?php echo e(trans('permissible::core.please_select_role')); ?>" <?php if($user->hasRole("su")): ?> disabled="true" <?php endif; ?>>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role->id); ?>" <?php if($user->hasRole($role->code)): ?> selected <?php endif; ?>><?php echo e($role->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                   
                        <?php if($errors->has('role')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('role')); ?></strong>
                            </span>
                        <?php endif; ?>
                </div>

            </div>

            <div class="row">

                <div class="form-group col-md-6">
                    <label class="control-label"><?php echo e(trans('permissible::core.password')); ?><span class="required">*</span></label>
                    <input type="password" class="form-control" placeholder="Password" name="password"/>

                    <?php if($errors->has('password')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="form-group col-md-6">
                    <label class="control-label"><?php echo e(trans('permissible::core.password_confirmation')); ?><span class="required">*</span></label>
                    <input type="password" class="form-control" placeholder="Retype password" name="password_confirmation"/>
                </div>

            </div>

        </div>

        <div class="card-footer">
            <button class="btn btn-md btn-success" type="submit" style="border-radius: 0px !important;"><?php echo e(trans('permissible::core.save')); ?></button>
        </div>

        </form>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('redprintUnity::page', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>