<?php $__env->startSection('title'); ?> Valor - Index <?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title'); ?> Valor <?php $__env->stopSection(); ?>
<?php $__env->startSection('page_subtitle'); ?> Index <?php $__env->stopSection(); ?>
<?php $__env->startSection('page_icon'); ?> <i class="icon-folder"></i> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">

        <div class="card-header">
            <a href="<?php echo e(route('valor.new')); ?>" class="btn btn-success"><i class="fa fa-plus-circle"></i>&nbsp;&nbsp;<?php echo e(trans('redprint::core.new')); ?></a>
            <div class="btn-group float-right">
                <?php if(count(Request::input())): ?>
                    <a class="btn btn-default" href="<?php echo e(route('valor.index')); ?>"><?php echo e(trans('redprint::core.clear')); ?></a>
                    <a class="btn btn-primary" id="searchButton" data-toggle="modal" data-target="#searchModal" href="#"><?php echo e(trans('redprint::core.modify_search')); ?></a>
                <?php else: ?>
                    <a class="btn btn-primary" id="searchButton" data-toggle="modal" data-target="#searchModal" href="#"><i class="icon-search"></i>&nbsp;&nbsp;<?php echo e(trans('redprint::core.search')); ?></a>
                <?php endif; ?>
            </div>
        </div>


        <div class="card-body">
            <table class="table table-striped table-hover table-bordered">
                <tbody>
                    <thead>
                        <tr>
                            <td>Pregunta</td>
                            <td>Tipo</td>
                            <td>Valores</td>

                            <th><?php echo e(trans('redprint::core.actions')); ?></th>
                        </tr>
                    </thead>
                    <?php 
                        $tipo = "no";
                    ?>
                    <?php $__currentLoopData = $valorsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valorItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <tr>
                        <?php if($tipo !==  $valorItem->pregunta->pregunta ): ?>
                            <td> <?php echo e($valorItem->pregunta->pregunta); ?> </td>
                            <td> <?php echo e($valorItem->pregunta->tipo); ?> </td>
                            
                        <?php else: ?>
                            <td></td>
                            <td></td>
                        <?php endif; ?>    
                        <td> <?php echo e($valorItem->valor); ?></td>
                        
                        <th>
                            <?php if(!$valorItem->deleted_at): ?>
                                <a href="<?php echo e(route('valor.form', $valorItem->id)); ?>" class="btn btn-primary btn-xs"><?php echo e(trans('redprint::core.edit')); ?></a>
                                <a href="#" class="btn btn-xs btn-warning" data-target="#deleteModal<?php echo e($valorItem->id); ?>" data-toggle="modal" ><?php echo e(trans('redprint::core.delete')); ?></a>


                                <!-- modal starts -->
                                <div class="modal fade" id="deleteModal<?php echo e($valorItem->id); ?>">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form class="form-horizontal" method="post" action="<?php echo e(route('valor.delete', $valorItem->id)); ?>" >
                                            <?php echo csrf_field(); ?>

                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                <h4 class="modal-title"> <?php echo e(trans('redprint::core.delete')); ?>: <?php echo e($valorItem->id); ?> </h4>
                                            </div>
                            
                                            <div class="modal-body">
                                                <?php echo e(trans('redprint::core.confirm_delete')); ?> <strong><?php echo e($valorItem->id); ?> ?</strong>
                                            </div>
                            
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(trans('redprint::core.close')); ?></button>
                                                <button type="submit" class="btn btn-danger"><?php echo e(trans('redprint::core.delete')); ?></button>
                                            </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <!-- modal ends -->

                            <?php else: ?>

                                <a href="#" class="btn btn-xs btn-success" data-target="#restoreModal<?php echo e($valorItem->id); ?>" data-toggle="modal" >Restore</a>
                                <a href="#" class="btn btn-xs btn-danger" data-target="#forceDeleteModal<?php echo e($valorItem->id); ?>" data-toggle="modal" ><?php echo e(trans('redprint::core.permanently_delete')); ?></a>


                                <!-- modal starts -->
                                <div class="modal fade" id="restoreModal<?php echo e($valorItem->id); ?>">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form class="form-horizontal" method="post" action="<?php echo e(route('valor.restore', $valorItem->id)); ?>" >
                                            <?php echo csrf_field(); ?>


                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                <h4 class="modal-title"> <?php echo e(trans('redprint::core.restore')); ?>: <?php echo e($valorItem->id); ?> </h4>
                                            </div>
                            
                                            <div class="modal-body">
                                                <?php echo e(trans('redprint::core.confirm_restore')); ?> <code><?php echo e($valorItem->id); ?> ?</code>
                                            </div>
                            
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(trans('redprint::core.close')); ?></button>
                                                <button type="submit" class="btn btn-primary"><?php echo e(trans('redprint::core.restore')); ?></button>
                                            </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <!-- modal ends -->



                                <!-- modal starts -->
                                <div class="modal fade" id="forceDeleteModal<?php echo e($valorItem->id); ?>">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form class="form-horizontal" method="post" action="<?php echo e(route('valor.force-delete', $valorItem->id)); ?>" >
                                            <?php echo csrf_field(); ?>

                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                <h4 class="modal-title"> Permanently: <?php echo e($valorItem->id); ?> </h4>
                                            </div>
                            
                                            <div class="modal-body">
                                                <?php echo e(trans('redprint::core.confirm_permanent_delete')); ?> <strong><?php echo e($valorItem->id); ?> </strong> ? <?php echo e(trans('redprint::core.permanent_delete_warning')); ?>

                                            </div>
                            
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(trans('redprint::core.close')); ?></button>
                                                <button type="submit" class="btn btn-primary"><?php echo e(trans('redprint::core.permanently_delete')); ?></button>
                                            </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <!-- modal ends -->

                            <?php endif; ?>
                        </th>
                    </tr>
                    <?php $tipo = $valorItem->pregunta->pregunta ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer">
            <?php echo $valorsData->links(); ?>

        </div>
    </div>

    <?php $__env->startSection('modals'); ?>
    ##parent-placeholder-0c1c163a4d648da177a48fddc7a3a5a788b17ac6##
    <!-- valor search modal -->
    <div class="modal fade" id="searchModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <form class="form-horizontal" method="get" action="<?php echo e(route('valor.index')); ?>" >
                <?php echo csrf_field(); ?>

                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"><?php echo e(trans('redprint::core.search')); ?> valors</h4>
                </div>

                <div class="modal-body">                  
                                                            
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(trans('redprint::core.close')); ?></button>
                    <button type="submit" class="btn btn-primary"><?php echo e(trans('redprint::core.search')); ?></button>
                </div>
                </form>
            </div>
        </div>
    </div>
    <!-- search modal ends -->
    <?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make(config('main-app-layout', 'redprintUnity::page'), \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>