<?php

return  [
  0 => 
   [
    'text' => 'Clientes',
    'route' => 'cliente.index',
    'icon' => 'icon-folder',
  ],
  1 => 
   [
    'text' => 'Tarjetas',
    'route' => 'tarjeta.index',
    'icon' => 'icon-folder',
  ],
  2 => 
   [
    'text' => 'Acompañantes',
    'route' => 'acompanante.index',
    'icon' => 'icon-folder',
  ],
  3 => 
   [
    'text' => 'Preguntas',
    'route' => 'pregunta.index',
    'icon' => 'icon-folder',
  ],
  4 => 
   [
    'text' => 'Asignar Valores ',
    'route' => 'valor.index',
    'icon' => 'icon-folder',
  ],
  5 => 
   [
    'text' => 'Cuestionarios',
    'route' => 'cuestionario.index',
    'icon' => 'icon-folder',
  ],
]
;