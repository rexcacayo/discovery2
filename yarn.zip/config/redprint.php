<?php
  return [
    'redprint-layout' => 'redprintUnity::page',
    'main-app-layout' => 'redprintUnity::page',
  ];