<?php
  return [
    'enable_routes' => true,
    'enable_user_management_routes' => true,
    'first_last_name_migration' => true,
    'default_fallback_route' => 'backend.dashboard',
    'hierarchy' => true,
  ];